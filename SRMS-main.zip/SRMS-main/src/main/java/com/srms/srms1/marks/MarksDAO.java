package com.srms.srms1.marks;

import java.util.List;

public interface MarksDAO {

    public void insertMarks(List<Marks> marks);
//    public List<Marks> studentMarks();


}
